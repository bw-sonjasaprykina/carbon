The list of Tag `type` values, in the order the system presents them: red, magenta, purple, blue, cyan, teal, green, gray, cool-gray, warm-gray, high-contrast, outline.

```jsx
TAG_COLORS.map(c => <Tag key={c} type={c}>{c}</Tag>)
```

It is a constant, not a component. Use it to build pickers or specimen rows rather than hard-coding the names.
