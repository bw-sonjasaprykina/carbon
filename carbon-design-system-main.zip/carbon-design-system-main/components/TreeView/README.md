Nested hierarchies where depth matters — file trees, resource groups, taxonomy pickers.

\`\`\`jsx
<TreeView label="Resources" nodes={[
  { label: 'us-south', open: true, icon: <Icon name="Folder" />, children: [
    { label: 'cluster-a', selected: true, active: true },
    { label: 'cluster-b' },
  ]},
]} />
\`\`\`

Each level indents 16px. Branch nodes get a caret that rotates 90° when open; leaf nodes keep the 16px caret well empty so labels stay aligned.
