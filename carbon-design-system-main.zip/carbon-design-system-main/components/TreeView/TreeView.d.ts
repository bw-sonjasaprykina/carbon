import * as React from 'react';

export interface TreeNodeSpec {
  label: string;
  icon?: React.ReactNode;
  children?: TreeNodeSpec[];
  /** Branch starts expanded. */
  open?: boolean;
  selected?: boolean;
  /** Active node — gets the 3px inset left border. */
  active?: boolean;
  disabled?: boolean;
}

/** Carbon Tree view — nested hierarchy with expandable branch nodes. */
export interface TreeViewProps {
  /** Accessible label, also rendered above the tree unless hidden. */
  label?: string;
  nodes?: TreeNodeSpec[];
  /** Row height: 24 or 32px. @default "sm" */
  size?: 'xs' | 'sm';
  /** @default false */
  hideLabel?: boolean;
  style?: React.CSSProperties;
}
export declare function TreeView(props: TreeViewProps): JSX.Element;
