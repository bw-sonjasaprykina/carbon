# Forms

Text, number, password, select, dropdown, checkbox, radio, toggle, search, slider, date, time, uploader

The Forms showcase page from the standalone version (`components/forms/forms.card.html`): plain HTML with the system’s classes — copy the markup.
