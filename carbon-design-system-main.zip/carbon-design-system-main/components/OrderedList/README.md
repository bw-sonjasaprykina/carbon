A numbered list for steps that happen in sequence.

```jsx
<OrderedList items={['Create a cluster', 'Attach a volume', 'Deploy the app']} />
```

Props: `items`, `children`, `nested`, `native`, `style`. Items passed through `items` are numbered for you. Children you add yourself need `index` and `ordered` on their ListItem. `native` switches to the browser's decimal markers, but ListItem lays itself out with flex, which hides those markers, so leave `native` off.
