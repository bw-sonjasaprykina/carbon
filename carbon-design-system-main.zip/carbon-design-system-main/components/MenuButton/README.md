A button whose only job is to open a menu of related actions — use when three or more actions share one entry point.

\`\`\`jsx
<MenuButton label="Create" items={[{ label: 'Service' }, { label: 'Resource group' }, { kind: 'divider' }, { label: 'Delete', danger: true }]} />
\`\`\`

Composes Button and Menu. The chevron rotates on open. For a split primary action use ComboButton instead.
