import * as React from 'react';
import { ButtonKind, ButtonSize } from './Button';
import { MenuItemSpec } from '../navigation/Menu';

/** A Button that opens a Carbon Menu of secondary actions. */
export interface MenuButtonProps {
  /** Trigger label. @default "Actions" */
  label?: string;
  /** Menu contents. */
  items?: MenuItemSpec[];
  /** @default "primary" */
  kind?: ButtonKind;
  /** @default "lg" */
  size?: ButtonSize;
  disabled?: boolean;
  /** Which side the menu opens on. @default "bottom" */
  menuAlignment?: 'top' | 'bottom';
  style?: React.CSSProperties;
}
export declare function MenuButton(props: MenuButtonProps): JSX.Element;
