import * as React from 'react';
import { MenuItemSpec } from '../navigation/Menu';

export interface DataTableHeader {
  /** Key into each row object. */
  key: string;
  /** Column heading text. */
  header: React.ReactNode;
  /** Set false to make the column unsortable. @default true */
  sortable?: boolean;
}

export interface DataTableRow {
  [key: string]: any;
  /** Content revealed when the row is expanded. */
  expandedContent?: React.ReactNode;
  /** Overrides the default overflow-menu items for this row. */
  actions?: MenuItemSpec[];
}

/**
 * Carbon Data table — sortable, selectable, expandable rows in five densities.
 * @startingPoint section="Data" subtitle="Sortable, selectable data table with batch action bar" viewport="700x400"
 */
export interface DataTableProps {
  headers?: DataTableHeader[];
  rows?: DataTableRow[];
  /** Row height: xs 24, sm 32, md 40, lg 48, xl 64px. @default "lg" */
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  /** Table title above the header row. */
  title?: string;
  description?: string;
  /** Row checkboxes and the blue batch-action bar. @default false */
  selectable?: boolean;
  /** Per-row expansion carets. @default false */
  expandable?: boolean;
  /** Trailing overflow menu on each row. @default false */
  withOverflow?: boolean;
  /** Alternate row shading. @default false */
  zebra?: boolean;
  sticky?: boolean;
  /** Toolbar content (Search, filter buttons) shown when nothing is selected. */
  toolbar?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function DataTable(props: DataTableProps): JSX.Element;
