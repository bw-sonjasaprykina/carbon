The workhorse for structured records. Header cells are semibold on \`--cds-layer-accent-01\`; body cells are \`--cds-text-secondary\`.

\`\`\`jsx
<DataTable size="lg" selectable expandable withOverflow
  headers={[{ key: 'name', header: 'Name' }, { key: 'status', header: 'Status' }]}
  rows={[{ name: 'cluster-a', status: <Tag type="green">Running</Tag>, expandedContent: 'us-south · 3 nodes' }]}
  toolbar={<Search size="lg" placeholder="Search" />} />
\`\`\`

Selecting rows replaces the toolbar with the blue batch-action bar. Sorting cycles ascending → descending → none. Densities: xs 24, sm 32, md 40, lg 48, xl 64px.
