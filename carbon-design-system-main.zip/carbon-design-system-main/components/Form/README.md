Form layout primitives. FormGroup gives related fields a 12px legend, 24px internal spacing and 32px below.

\`\`\`jsx
<Form>
  <FormGroup legend="Cluster details">
    <TextInput id="n" label="Name" />
    <Select id="r" label="Region" items={['us-south']} />
  </FormGroup>
  <Stack orientation="horizontal" gap={8}>
    <Button kind="secondary">Cancel</Button>
    <Button kind="primary">Create</Button>
  </Stack>
</Form>
\`\`\`

Never centre a form. Action buttons go bottom-left, cancel before submit.
