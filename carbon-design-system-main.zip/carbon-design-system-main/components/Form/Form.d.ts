import * as React from 'react';

/** Carbon Form wrapper. */
export interface FormProps extends React.FormHTMLAttributes<HTMLFormElement> {
  children?: React.ReactNode;
}
export declare function Form(props: FormProps): JSX.Element;

/** A titled group of related fields, 24px apart, with 32px below the group. */
export interface FormGroupProps {
  legend?: string;
  children?: React.ReactNode;
  /** @default true */
  hasMargin?: boolean;
  style?: React.CSSProperties;
}
export declare function FormGroup(props: FormGroupProps): JSX.Element;

/** The standalone 12px field label, for composing custom controls. */
export interface FormLabelProps {
  children?: React.ReactNode;
  htmlFor?: string;
  style?: React.CSSProperties;
}
export declare function FormLabel(props: FormLabelProps): JSX.Element;

/** Spacing primitive — a flex row or column with a token gap. */
export interface StackProps {
  children?: React.ReactNode;
  /** @default 16 */
  gap?: number;
  /** @default "vertical" */
  orientation?: 'vertical' | 'horizontal';
  style?: React.CSSProperties;
}
export declare function Stack(props: StackProps): JSX.Element;
