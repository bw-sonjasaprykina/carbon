import * as React from 'react';

export interface MenuItemSpec {
  /** Item text. */
  label?: string;
  /** Render a 1px separator instead of an item. */
  kind?: 'item' | 'divider';
  /** Leading icon element. */
  icon?: React.ReactNode;
  /** Trailing keyboard shortcut, e.g. "⌘S". */
  shortcut?: string;
  /** Destructive item — hovers to the danger colour. */
  danger?: boolean;
  disabled?: boolean;
  onClick?: () => void;
}

/**
 * Carbon Menu — the floating list used by MenuButton, ComboButton, OverflowMenu and right-click menus.
 * @startingPoint section="Navigation" subtitle="Floating action menu with dividers and shortcuts" viewport="700x220"
 */
export interface MenuProps {
  items?: MenuItemSpec[];
  /** Row height: 24 / 28 / 32 / 40px. @default "md" */
  size?: 'xs' | 'sm' | 'md' | 'lg';
  onSelect?: (item: MenuItemSpec) => void;
  style?: React.CSSProperties;
}
export declare function Menu(props: MenuProps): JSX.Element;
