The floating list of actions. Rarely used alone — MenuButton, ComboButton and OverflowMenu all render it.

\`\`\`jsx
<Menu size="md" items={[
  { label: 'Open', shortcut: '⌘O' },
  { label: 'Copy', icon: <Icon name="Copy" /> },
  { kind: 'divider' },
  { label: 'Delete', danger: true },
]} />
\`\`\`

Sits on \`--cds-layer-02\` with a 2px/6px shadow; rows are 32px at the default size. Dividers are 1px, inset 16px.
