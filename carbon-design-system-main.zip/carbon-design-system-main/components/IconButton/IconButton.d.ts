import * as React from 'react';
import { ButtonKind, ButtonSize } from './Button';

/** An icon-only Button that reveals its label as a tooltip on hover and focus. */
export interface IconButtonProps extends React.HTMLAttributes<HTMLElement> {
  /** Accessible label, also the tooltip text. Required. */
  label: string;
  /** The icon element. */
  children: React.ReactNode;
  /** @default "ghost" */
  kind?: ButtonKind;
  /** @default "lg" */
  size?: ButtonSize;
  /** Tooltip side. @default "bottom" */
  align?: 'top' | 'bottom' | 'left' | 'right';
  disabled?: boolean;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
