An icon-only button whose label appears as a Carbon tooltip — use it anywhere a bare glyph would otherwise be unlabelled (toolbars, table row actions, shell header).

\`\`\`jsx
<IconButton label="Settings" align="bottom"><Icon name="Settings" size={16} /></IconButton>
\`\`\`

Defaults to the ghost kind at 48px. Never use a plain Button with only an icon and no \`aria-label\`.
