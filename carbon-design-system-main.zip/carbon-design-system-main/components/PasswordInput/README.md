A text input with an eye toggle. Use for any masked credential; never hide the toggle.

\`\`\`jsx
<PasswordInput id="pw" label="Password" helperText="At least 12 characters" />
\`\`\`

The toggle is a square the same size as the field height, sitting inside the trailing padding.
