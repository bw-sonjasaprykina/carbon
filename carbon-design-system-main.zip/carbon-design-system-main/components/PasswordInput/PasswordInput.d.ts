import * as React from 'react';

/** Carbon Password input — text input with a show/hide toggle in the trailing well. */
export interface PasswordInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  id?: string;
  /** @default "Password" */
  label?: string;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  helperText?: string;
  invalid?: boolean;
  invalidText?: string;
  disabled?: boolean;
}
export declare function PasswordInput(props: PasswordInputProps): JSX.Element;
