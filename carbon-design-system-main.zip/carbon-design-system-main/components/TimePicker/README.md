An 80px time field followed by period and time-zone Selects, joined by 1px gaps.

\`\`\`jsx
<TimePicker id="t" label="Start time" value="09:30" zones={['UTC', 'CET', 'JST']} />
\`\`\`

Pass \`zones={[]}\` when the zone is implied. Pair with DatePicker for a full timestamp.
