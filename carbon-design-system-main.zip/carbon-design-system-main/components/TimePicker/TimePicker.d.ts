import * as React from 'react';

/** Carbon Time picker — a short time field plus AM/PM and time-zone selects. */
export interface TimePickerProps {
  id?: string;
  /** @default "Time" */
  label?: string;
  value?: string;
  /** @default "hh:mm" */
  placeholder?: string;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** AM/PM options. @default ["AM","PM"] */
  periods?: string[];
  /** Time-zone options; pass [] to hide the zone select. */
  zones?: string[];
  disabled?: boolean;
  invalid?: boolean;
  invalidText?: string;
  style?: React.CSSProperties;
}
export declare function TimePicker(props: TimePickerProps): JSX.Element;
