import * as React from 'react';

export interface ContainedListItemSpec {
  label: React.ReactNode;
  icon?: React.ReactNode;
  /** Trailing element — an icon button, tag or count. */
  action?: React.ReactNode;
  onClick?: () => void;
  href?: string;
}

/** Carbon Contained list — a titled list with an action slot in its header. */
export interface ContainedListProps {
  /** Bold 16px list title. */
  label?: React.ReactNode;
  /** "on-page" sits on the page ground; "disclosed" sits on layer-02 inside a container. @default "on-page" */
  kind?: 'on-page' | 'disclosed';
  /** Row height: 24 / 32 / 40 / 48px. @default "md" */
  size?: 'xs' | 'sm' | 'md' | 'lg';
  /** Header action — a Search, IconButton or Button. */
  action?: React.ReactNode;
  items?: ContainedListItemSpec[];
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function ContainedList(props: ContainedListProps): JSX.Element;
