A titled list with its own header action — good for side panels and dashboard cards.

\`\`\`jsx
<ContainedList label="Recent deploys" action={<IconButton label="Filter"><Icon name="Filter" /></IconButton>}
  items={[{ label: 'build-1042', action: <Tag type="green" size="sm">passed</Tag> }]} />
\`\`\`

Rows are 40px by default on \`--cds-layer-01\` with 1px rules. \`kind="disclosed"\` when nested inside another surface.
