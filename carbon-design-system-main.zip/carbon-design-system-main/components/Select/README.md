Use Select for a short, fixed list the user already knows (country, region, plan). Use Dropdown when options need icons, descriptions or filtering.

\`\`\`jsx
<Select id="region" label="Region" items={['us-south', 'eu-de', 'jp-tok']} />
<Select inline hideLabel items={['Last 24 hours', 'Last 7 days']} />
\`\`\`

The chevron is decorative (\`pointer-events: none\`) and sits 16px from the trailing edge.
