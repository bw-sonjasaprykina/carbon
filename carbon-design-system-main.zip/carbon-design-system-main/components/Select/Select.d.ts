import * as React from 'react';

/** Carbon Select — native select styled as a Carbon field, with an inline variant. */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  id?: string;
  label?: string;
  /** Option strings, or { label, value, disabled } objects. */
  items?: (string | { label: string; value: string; disabled?: boolean })[];
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  helperText?: string;
  invalid?: boolean;
  invalidText?: string;
  disabled?: boolean;
  /** Borderless, transparent variant for use inside toolbars and table headers. @default false */
  inline?: boolean;
  hideLabel?: boolean;
}
export declare function Select(props: SelectProps): JSX.Element;
