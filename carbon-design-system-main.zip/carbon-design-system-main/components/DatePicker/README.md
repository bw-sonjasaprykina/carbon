A date field with a calendar flyout. \`range\` renders two fields side by side with a 1px gap.

\`\`\`jsx
<DatePicker id="start" label="Start date" month={8} year={2026} selectedDay={12} />
<DatePicker id="window" label="Reporting window" range />
\`\`\`

The calendar is 288px wide on \`--cds-layer-01\`; day cells are 40px tall and the selected day fills \`--cds-interactive\`. Weekday initials are semibold.
