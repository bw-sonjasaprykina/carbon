import * as React from 'react';

/**
 * Carbon Date picker — single or range field with a 288px calendar flyout.
 * @startingPoint section="Forms" subtitle="Date field with calendar flyout" viewport="700x400"
 */
export interface DatePickerProps {
  id?: string;
  /** @default "Date" */
  label?: string;
  value?: string;
  /** @default "mm/dd/yyyy" */
  placeholder?: string;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Render a second field for a date range. @default false */
  range?: boolean;
  disabled?: boolean;
  invalid?: boolean;
  invalidText?: string;
  helperText?: string;
  /** Calendar month to display, 0-indexed. */
  month?: number;
  year?: number;
  /** Day-of-month to render selected. */
  selectedDay?: number;
  style?: React.CSSProperties;
}
export declare function DatePicker(props: DatePickerProps): JSX.Element;
