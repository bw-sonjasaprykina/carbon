Inline SVG for one of the Carbon glyphs extracted from the Figma kit; paints with `currentColor`.

```jsx
<Icon name="ChevronDown" size={16} />
<span style={{ color: 'var(--cds-support-error)' }}><Icon name="ErrorFilled" size={20} /></span>
```

Sizes in Carbon are 16 / 20 / 24 / 32. Set colour on the icon or an ancestor via the CSS `color` property — never a `fill` prop.
The full name index lives in `Icon.d.ts`. Status glyphs: `CheckmarkFilled`, `ErrorFilled`, `WarningFilled`, `WarningAltFilled`, `InformationFilled`, `InProgress`, `Incomplete`, `PendingFilled`, `UndefinedFilled`, `UnknownFilled`.
