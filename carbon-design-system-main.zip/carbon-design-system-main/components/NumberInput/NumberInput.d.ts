import * as React from 'react';

/** Carbon Number input — numeric field with increment/decrement steppers. */
export interface NumberInputProps {
  id?: string;
  label?: string;
  value?: number;
  /** @default 0 */
  defaultValue?: number;
  min?: number;
  max?: number;
  /** @default 1 */
  step?: number;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  helperText?: string;
  invalid?: boolean;
  invalidText?: string;
  disabled?: boolean;
  /** Hide the steppers (keyboard/typed entry only). @default false */
  hideSteppers?: boolean;
  onChange?: (value: number) => void;
  style?: React.CSSProperties;
}
export declare function NumberInput(props: NumberInputProps): JSX.Element;
