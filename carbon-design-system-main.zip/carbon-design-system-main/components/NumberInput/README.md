Numeric entry with steppers. Use when the value has a meaningful step; use TextInput for free-form numbers like IDs.

\`\`\`jsx
<NumberInput id="replicas" label="Replicas" defaultValue={3} min={1} max={10} helperText="1 to 10" />
\`\`\`

The two square steppers sit at the trailing edge, separated by a 1px rule, and disable at the min/max bound.
