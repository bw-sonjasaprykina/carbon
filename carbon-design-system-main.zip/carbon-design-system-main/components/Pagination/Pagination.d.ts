import * as React from 'react';

/** Carbon Pagination — page-size select, range readout and prev/next controls. */
export interface PaginationProps {
  totalItems?: number;
  /** @default 10 */
  pageSize?: number;
  /** @default [10,20,50] */
  pageSizes?: number[];
  /** @default 1 */
  page?: number;
  onChange?: (state: { page: number; pageSize: number }) => void;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  style?: React.CSSProperties;
}
export declare function Pagination(props: PaginationProps): JSX.Element;
