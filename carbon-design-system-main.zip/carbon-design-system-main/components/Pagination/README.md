Sits directly under a DataTable, flush to its edges, on \`--cds-layer-01\` with a 1px top rule.

\`\`\`jsx
<Pagination totalItems={348} pageSize={10} pageSizes={[10, 20, 50]} />
\`\`\`

Left side: items-per-page select and the "1–10 of 348 items" readout. Right side: page count and two square nav buttons separated by 1px rules.
