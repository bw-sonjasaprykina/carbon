The three-dot affordance for actions that belong to one row, card or tile. Always right-aligned in a data table row.

\`\`\`jsx
<OverflowMenu items={[{ label: 'Edit' }, { label: 'Duplicate' }, { kind: 'divider' }, { label: 'Delete', danger: true }]} />
\`\`\`

\`direction="horizontal"\` rotates the dots (used in breadcrumb overflow). Never put a destructive action first.
