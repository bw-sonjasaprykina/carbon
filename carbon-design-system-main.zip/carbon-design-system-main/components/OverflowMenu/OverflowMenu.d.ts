import * as React from 'react';
import { MenuItemSpec } from '../navigation/Menu';

/** The three-dot trigger that reveals a Menu of row- or card-level actions. */
export interface OverflowMenuProps {
  items?: MenuItemSpec[];
  /** Trigger square: 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Dot orientation. @default "vertical" */
  direction?: 'vertical' | 'horizontal';
  /** Open the menu to the right of the trigger instead of the left. @default false */
  flipped?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function OverflowMenu(props: OverflowMenuProps): JSX.Element;
