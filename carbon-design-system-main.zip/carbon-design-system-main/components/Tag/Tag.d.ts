import * as React from 'react';

export type TagType = 'red' | 'magenta' | 'purple' | 'blue' | 'cyan' | 'teal' | 'green' | 'gray' | 'cool-gray' | 'warm-gray' | 'high-contrast' | 'outline';

/**
 * Carbon Tag — pill label in 12 colour families, three sizes, with filter/selectable variants.
 * @startingPoint section="Data" subtitle="All 12 tag colours, three sizes, filter and selectable" viewport="700x200"
 */
export interface TagProps {
  children?: React.ReactNode;
  /** Colour family. @default "gray" */
  type?: TagType;
  /** 18 / 24 / 32px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Adds the round close button (filter tag). @default false */
  filter?: boolean;
  /** Selectable variant — toggles between enabled and inverse-selected. @default false */
  selectable?: boolean;
  /** Initial selected state for the selectable variant. @default false */
  selected?: boolean;
  disabled?: boolean;
  /** Leading icon, painted in the family's icon colour. */
  renderIcon?: React.ReactNode;
  /** Supplying onClose also renders the close button. */
  onClose?: () => void;
  /** Close-button tooltip. @default "Clear filter" */
  title?: string;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
export declare const TAG_COLORS: TagType[];
