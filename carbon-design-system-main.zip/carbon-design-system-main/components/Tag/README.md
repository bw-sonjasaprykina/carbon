Categorises or filters. Tags are fully rounded pills — never square. Each colour family carries its own background/text/hover/icon tokens, so pass \`type\` rather than overriding colour.

\`\`\`jsx
<Tag type="green" renderIcon={<Icon name="CheckmarkFilled" size={12} />}>Running</Tag>
<Tag type="blue" filter onClose={() => {}}>region: us-south</Tag>
<Tag selectable>Production</Tag>
\`\`\`

Colours: red, magenta, purple, blue, cyan, teal, green, gray, cool-gray, warm-gray, high-contrast, outline. Use status colour meaningfully (green = healthy, red = failed) or stay gray.
