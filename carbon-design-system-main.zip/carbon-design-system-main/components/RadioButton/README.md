Exactly-one selection from two to five visible options. More than five, use a Dropdown.

\`\`\`jsx
<RadioButtonGroup legend="Plan" orientation="vertical">
  <RadioButton id="lite" name="plan" label="Lite" defaultChecked />
  <RadioButton id="std" name="plan" label="Standard" />
</RadioButtonGroup>
\`\`\`

Circles are 18px with an 8px dot. Horizontal groups gap 24px, vertical 8px. Always render a legend.
