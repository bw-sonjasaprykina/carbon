import * as React from 'react';

/** Carbon Radio button — 18px circle with an 8px inner dot. */
export interface RadioButtonProps {
  id?: string;
  /** Shared group name. */
  name?: string;
  label?: React.ReactNode;
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (id?: string) => void;
  disabled?: boolean;
  /** @default "right" */
  labelPosition?: 'left' | 'right';
  style?: React.CSSProperties;
}
export declare function RadioButton(props: RadioButtonProps): JSX.Element;

/** Groups radios under one legend, horizontally (24px gap) or vertically (8px gap). */
export interface RadioButtonGroupProps {
  legend?: string;
  children?: React.ReactNode;
  /** @default "horizontal" */
  orientation?: 'horizontal' | 'vertical';
  helperText?: string;
  invalid?: boolean;
  invalidText?: string;
  style?: React.CSSProperties;
}
export declare function RadioButtonGroup(props: RadioButtonGroupProps): JSX.Element;
