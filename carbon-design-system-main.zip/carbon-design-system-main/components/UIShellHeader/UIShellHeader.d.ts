import * as React from 'react';

export interface ShellNavItemSpec { label: string; href?: string; selected?: boolean; }
export interface ShellActionSpec { label: string; icon?: React.ReactNode; active?: boolean; onClick?: () => void; }

/**
 * Carbon UI shell header — the 48px black bar that anchors every product.
 * @startingPoint section="Shell" subtitle="48px product header with nav and action icons" viewport="700x48"
 */
export interface UIShellHeaderProps {
  /** Bold company prefix. @default "IBM" */
  prefix?: string;
  /** Product name in regular weight. */
  name?: string;
  /** Top-level nav links. */
  navItems?: ShellNavItemSpec[];
  /** Right-hand icon actions (search, notifications, app switcher…). */
  actions?: ShellActionSpec[];
  /** Show the hamburger and wire it up. @default false */
  hasSideNav?: boolean;
  onMenuClick?: () => void;
  style?: React.CSSProperties;
}
export declare function UIShellHeader(props: UIShellHeaderProps): JSX.Element;
