The product header: always 48px tall, always \`--cds-background-inverse\`, always first in the DOM.

\`\`\`jsx
<UIShellHeader hasSideNav prefix="IBM" name="Cloud Pak"
  navItems={[{ label: 'Catalog', selected: true }, { label: 'Resources' }]}
  actions={[{ label: 'Search', icon: <Icon name="Search" size={20} /> }, { label: 'Notifications', icon: <Icon name="Information" size={20} /> }]} />
\`\`\`

Action squares are 48×48. The selected nav item gets a 3px inset top border in \`--cds-border-interactive\`. The prefix is semibold, the product name regular.
