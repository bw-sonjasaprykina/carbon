import * as React from 'react';

export interface SideNavItemSpec {
  label: string;
  href?: string;
  icon?: React.ReactNode;
  selected?: boolean;
  /** Child links — renders an expandable group instead of a link. */
  items?: SideNavItemSpec[];
  /** Group starts open. */
  open?: boolean;
}

/**
 * Carbon UI shell left panel — 256px side navigation, collapsible to a 48px rail.
 * @startingPoint section="Shell" subtitle="256px side navigation with expandable groups" viewport="256x400"
 */
export interface SideNavProps {
  items?: SideNavItemSpec[];
  /** Full 256px width vs 48px icon rail. @default true */
  expanded?: boolean;
  /** Icon-rail mode that expands on hover. @default false */
  rail?: boolean;
  style?: React.CSSProperties;
}
export declare function SideNav(props: SideNavProps): JSX.Element;
