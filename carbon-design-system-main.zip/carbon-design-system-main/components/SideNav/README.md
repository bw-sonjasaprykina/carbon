The shell's left panel: 256px expanded, 48px as a rail, rows 32px tall.

\`\`\`jsx
<SideNav items={[
  { label: 'Dashboard', icon: <Icon name="Analytics" />, selected: true },
  { label: 'Resources', icon: <Icon name="Folder" />, items: [{ label: 'Clusters' }, { label: 'Volumes' }] },
]} />
\`\`\`

The selected row gets a 3px inset left border in \`--cds-border-interactive\`, \`--cds-background-selected\` fill and a semibold label. It sits *below* the header, never above it.
