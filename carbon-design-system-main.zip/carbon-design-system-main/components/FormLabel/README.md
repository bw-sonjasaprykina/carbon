The 12px secondary-text label Carbon puts above a field; use it to label a custom control that has no built-in `label` prop.

```jsx
<FormLabel htmlFor="custom">Label text</FormLabel>
```

Props: `children`, `htmlFor` (the id of the control it labels), `style`. Built-in inputs already render their own label, so don't add a FormLabel to them.
