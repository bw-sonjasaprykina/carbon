import * as React from 'react';

/**
 * Carbon Tile — the square-cornered surface that groups related content.
 * @startingPoint section="Data" subtitle="Base, clickable, selectable and expandable tiles" viewport="700x220"
 */
export interface TileProps {
  children?: React.ReactNode;
  /** base | clickable | selectable | expandable. @default "base" */
  kind?: 'base' | 'clickable' | 'selectable' | 'expandable';
  /** Initial selected state for the selectable kind. @default false */
  selected?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  /** Turns a clickable tile into an anchor. */
  href?: string;
  /** Expandable tiles start open. @default false */
  expanded?: boolean;
  /** Always-visible content of an expandable tile; children become the revealed part. */
  aboveTheFold?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Tile(props: TileProps): JSX.Element;
