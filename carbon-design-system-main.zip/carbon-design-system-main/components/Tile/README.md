Carbon's container primitive. Square corners, 16px padding, \`--cds-layer-01\` ground, no drop shadow — depth comes from the layer token, not elevation.

\`\`\`jsx
<Tile>Static content</Tile>
<Tile kind="clickable" href="#">Go to the catalog</Tile>
<Tile kind="selectable">Standard plan</Tile>
<Tile kind="expandable" aboveTheFold={<strong>Usage</strong>}>Detailed breakdown…</Tile>
\`\`\`

Selectable tiles get a circular check top-right and a \`--cds-border-interactive\` outline when chosen. Never add \`border-radius\` to a tile.
