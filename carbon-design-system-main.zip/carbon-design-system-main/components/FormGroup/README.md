A fieldset with a legend that groups related fields inside a Form; its children sit in a 24px-gap column.

```jsx
<FormGroup legend="Cluster details">
  <TextInput id="name" label="Cluster name" />
  <Select id="region" label="Region" items={['us-south', 'eu-de']} />
</FormGroup>
```

Props: `legend`, `children`, `hasMargin` (default true, adds 32px below the group), `style`.
