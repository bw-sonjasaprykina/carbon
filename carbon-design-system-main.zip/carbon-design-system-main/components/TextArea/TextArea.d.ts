import * as React from 'react';

/** Carbon Text area — multi-line field with optional character counter. */
export interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  id?: string;
  label?: string;
  /** @default 4 */
  rows?: number;
  helperText?: string;
  invalid?: boolean;
  invalidText?: string;
  disabled?: boolean;
  readOnly?: boolean;
  /** Enables the n/max counter beside the label and caps input length. */
  maxCount?: number;
}
export declare function TextArea(props: TextAreaProps): JSX.Element;
