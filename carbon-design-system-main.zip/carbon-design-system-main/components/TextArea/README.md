Multi-line input. Only one size; height comes from \`rows\` and the user can drag to resize.

\`\`\`jsx
<TextArea id="desc" label="Description" rows={4} maxCount={500} helperText="Markdown supported" />
\`\`\`

Padding is 11px 16px. The character counter sits on the label row, right-aligned.
