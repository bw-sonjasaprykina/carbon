import * as React from 'react';

/**
 * Carbon Dropdown — a listbox trigger with a floating option list.
 * @startingPoint section="Forms" subtitle="Dropdown listbox with selected and disabled options" viewport="700x220"
 */
export interface DropdownProps {
  id?: string;
  /** Field label. \`label\` is accepted as an alias. */
  titleText?: string;
  label?: string;
  /** Option strings or { label, disabled } objects. */
  items?: (string | { label: string; disabled?: boolean })[];
  selectedItem?: string | { label: string };
  onChange?: (item: string | { label: string }) => void;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** "inline" drops the field chrome for toolbar use. @default "default" */
  type?: 'default' | 'inline';
  helperText?: string;
  invalid?: boolean;
  invalidText?: string;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Dropdown(props: DropdownProps): JSX.Element;
