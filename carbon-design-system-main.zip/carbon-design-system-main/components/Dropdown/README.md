Single-select from a list that may be long or need custom option rendering. Placeholder is "Choose an option".

\`\`\`jsx
<Dropdown titleText="Instance type" items={['Shared', 'Dedicated', { label: 'Bare metal', disabled: true }]} />
\`\`\`

Options are separated by 1px \`--cds-border-subtle-01\` rules; the list caps at 5.5 rows and scrolls. The selected option keeps \`--cds-layer-selected-01\`.
