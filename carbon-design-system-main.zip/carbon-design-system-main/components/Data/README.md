# Data display

DataTable, Pagination, Tag, Tile, CodeSnippet, structured and contained lists

The Data display showcase page from the standalone version (`components/data/data.card.html`): plain HTML with the system’s classes — copy the markup.
