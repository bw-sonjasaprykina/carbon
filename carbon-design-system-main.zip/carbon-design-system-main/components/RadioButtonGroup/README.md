A fieldset that holds a set of RadioButtons sharing one `name`, so exactly one can be chosen.

```jsx
<RadioButtonGroup legend="Plan" orientation="vertical">
  <RadioButton id="p1" name="plan" label="Lite" defaultChecked />
  <RadioButton id="p2" name="plan" label="Standard" />
</RadioButtonGroup>
```

Props: `legend`, `children`, `orientation` (`horizontal`, the default, or `vertical`), `helperText`, `invalid`, `invalidText`, `style`. Give every RadioButton inside the same `name`. Preselect one option unless choosing nothing is a valid answer.
