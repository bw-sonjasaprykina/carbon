import * as React from 'react';

/** Carbon Slider — 4px rail, 14px round handle, with an optional numeric text input. */
export interface SliderProps {
  id?: string;
  label?: string;
  /** @default 0 */
  min?: number;
  /** @default 100 */
  max?: number;
  /** @default 1 */
  step?: number;
  value?: number;
  /** @default 50 */
  defaultValue?: number;
  onChange?: (value: number) => void;
  disabled?: boolean;
  /** Drop the numeric field at the trailing edge. @default false */
  hideTextInput?: boolean;
  /** Override the rail end labels (e.g. "Low" / "High"). */
  minLabel?: React.ReactNode;
  maxLabel?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Slider(props: SliderProps): JSX.Element;
