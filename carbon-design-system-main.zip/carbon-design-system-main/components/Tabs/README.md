Switches between peer views of the same data. Line tabs for page-level navigation; contained tabs inside a card or panel.

\`\`\`jsx
<Tabs tabs={[{ label: 'Overview' }, { label: 'Logs' }, { label: 'Settings', disabled: true }]}>
  <div>Overview panel</div>
  <div>Logs panel</div>
  <div />
</Tabs>
\`\`\`

The selected line tab carries a 2px \`--cds-border-interactive\` underline and a semibold label. Do not use tabs for sequential steps — that's ProgressIndicator.
