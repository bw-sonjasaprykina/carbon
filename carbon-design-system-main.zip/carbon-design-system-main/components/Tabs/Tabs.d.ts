import * as React from 'react';

export interface TabSpec {
  label: string;
  icon?: React.ReactNode;
  disabled?: boolean;
}

/**
 * Carbon Tabs — line (default) or contained, three heights.
 * @startingPoint section="Navigation" subtitle="Line and contained tabs with panels" viewport="700x180"
 */
export interface TabsProps {
  tabs?: TabSpec[];
  /** Controlled selection index. @default 0 */
  selectedIndex?: number;
  onChange?: (index: number) => void;
  /** @default "line" */
  type?: 'line' | 'contained';
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Contained tabs sit on layer-accent with 1px dividers. @default false */
  contained?: boolean;
  /** One panel per tab, in order. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
