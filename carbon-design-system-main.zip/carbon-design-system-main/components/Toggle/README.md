A toggle applies immediately — no Save button. If the change needs confirming, use a Checkbox instead.

\`\`\`jsx
<Toggle id="t1" label="Auto-scaling" labelA="Disabled" labelB="Enabled" defaultToggled />
<Toggle id="t2" size="sm" hideLabel />
\`\`\`

On state is \`--cds-support-success\` (green), not blue; the knob carries a checkmark at the default size only.
