import * as React from 'react';

/** Carbon Toggle — immediate on/off switch. 48×24 default, 32×16 small. */
export interface ToggleProps {
  id?: string;
  /** 12px label above the switch. */
  label?: string;
  /** Text shown when off. @default "Off" */
  labelA?: string;
  /** Text shown when on. @default "On" */
  labelB?: string;
  toggled?: boolean;
  defaultToggled?: boolean;
  onChange?: (toggled: boolean) => void;
  disabled?: boolean;
  /** @default "md" */
  size?: 'sm' | 'md';
  /** Hide the on/off state text. @default false */
  hideLabel?: boolean;
  style?: React.CSSProperties;
}
export declare function Toggle(props: ToggleProps): JSX.Element;
