import * as React from 'react';

export interface UploadedFileSpec {
  name: string;
  /** @default "complete" */
  status?: 'uploading' | 'complete' | 'edit';
  invalid?: boolean;
}

/** Carbon File uploader — button or drag-and-drop zone plus a list of selected files. */
export interface FileUploaderProps {
  /** Bold 14px heading. @default "Upload files" */
  label?: string;
  /** 12px constraint copy under the heading. */
  description?: string;
  /** Button text in button mode. @default "Add file" */
  buttonLabel?: string;
  /** Render the dashed drop zone instead of a button. @default false */
  drop?: boolean;
  /** Pre-populated file rows. */
  files?: UploadedFileSpec[];
  multiple?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function FileUploader(props: FileUploaderProps): JSX.Element;
