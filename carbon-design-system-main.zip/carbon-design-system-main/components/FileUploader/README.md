Two modes: a tertiary "Add file" button, or \`drop\` for a 320px dashed drag-and-drop zone. Always state the size and type limits in \`description\`.

\`\`\`jsx
<FileUploader drop description="Max 500 MB. .csv only" files={[{ name: 'q3-usage.csv', status: 'complete' }, { name: 'q4.csv', status: 'uploading' }]} />
\`\`\`

File rows are 40px on \`--cds-layer-01\` with a 2px gap, and end in a spinner, a green check or a remove ×.
