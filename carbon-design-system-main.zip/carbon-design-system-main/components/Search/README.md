Filters or queries a set. Full-width in a toolbar; \`expandable\` when horizontal space is tight.

\`\`\`jsx
<Search size="lg" placeholder="Search resources" />
<Search size="sm" expandable labelText="Search table" />
\`\`\`

The magnifier is a real button (it focuses the field); the clear × only appears when there is a value. No label sits above a Search — the placeholder carries the meaning.
