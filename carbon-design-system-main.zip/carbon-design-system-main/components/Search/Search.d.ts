import * as React from 'react';

/** Carbon Search — leading magnifier, trailing clear button, optional expandable behaviour. */
export interface SearchProps {
  id?: string;
  /** Accessible label. @default "Search" */
  labelText?: string;
  /** @default "Search" */
  placeholder?: string;
  /** 32 / 40 / 48px. @default "lg" */
  size?: 'sm' | 'md' | 'lg';
  value?: string;
  defaultValue?: string;
  onChange?: (event: { target: { value: string } }) => void;
  disabled?: boolean;
  /** Collapses to an icon button until clicked. @default false */
  expandable?: boolean;
  style?: React.CSSProperties;
}
export declare function Search(props: SearchProps): JSX.Element;
