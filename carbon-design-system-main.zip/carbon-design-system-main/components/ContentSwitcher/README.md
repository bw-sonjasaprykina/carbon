Toggles between two to four views of the *same* content — a grid/list switch, a chart type. Not for navigation.

\`\`\`jsx
<ContentSwitcher items={[{ label: 'Chart' }, { label: 'Table' }]} />
<ContentSwitcher items={[{ label: 'Grid', icon: <Icon name="Analytics" />, iconOnly: true }, { label: 'List', icon: <Icon name="Document" />, iconOnly: true }]} />
\`\`\`

Selected segment inverts to \`--cds-background-inverse\`. Segments share 1px borders; only the last carries a right border.
