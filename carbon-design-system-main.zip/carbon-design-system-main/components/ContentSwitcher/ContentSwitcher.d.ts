import * as React from 'react';

export interface ContentSwitcherItemSpec {
  label: string;
  icon?: React.ReactNode;
  /** Show only the icon; the label becomes the tooltip/title. */
  iconOnly?: boolean;
  disabled?: boolean;
}

/** Carbon Content switcher — mutually exclusive views of the same content. */
export interface ContentSwitcherProps {
  items?: ContentSwitcherItemSpec[];
  /** @default 0 */
  selectedIndex?: number;
  onChange?: (index: number) => void;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Low-contrast selection (layer instead of inverse background). @default false */
  lowContrast?: boolean;
  style?: React.CSSProperties;
}
export declare function ContentSwitcher(props: ContentSwitcherProps): JSX.Element;
