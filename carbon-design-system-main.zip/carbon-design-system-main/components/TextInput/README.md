The default single-line field. Carbon fields have no box border — only a 1px bottom rule on a filled \`--cds-field-01\` ground.

\`\`\`jsx
<TextInput id="name" label="Cluster name" placeholder="my-cluster" helperText="Lowercase letters and hyphens only" />
<TextInput id="key" label="API key" invalid invalidText="This key is no longer valid" />
\`\`\`

Labels are 12px \`--cds-text-secondary\`, 8px above the field. Invalid swaps the bottom rule for a 2px red border and shows the error glyph; warn keeps the rule and shows the amber triangle.
