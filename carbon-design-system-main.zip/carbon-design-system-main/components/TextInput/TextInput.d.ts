import * as React from 'react';

/**
 * Carbon Text input — single-line field with label, helper text and validation states.
 * @startingPoint section="Forms" subtitle="Text input with label, helper, invalid and warn states" viewport="700x260"
 */
export interface TextInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  id?: string;
  /** 12px label above the field. */
  label?: string;
  /** 32 / 40 / 48px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** 12px helper text under the field. */
  helperText?: string;
  /** Error state: 2px red bottom border + error glyph. @default false */
  invalid?: boolean;
  invalidText?: string;
  /** Warning state: warning glyph, border unchanged. @default false */
  warn?: boolean;
  warnText?: string;
  disabled?: boolean;
  readOnly?: boolean;
  /** Visually hide the label (keep it for screen readers). @default false */
  hideLabel?: boolean;
  /** Label to the left of the field instead of above. @default false */
  inline?: boolean;
}
export declare function TextInput(props: TextInputProps): JSX.Element;
export declare function StatusGlyph(props: { color: string; name: 'error' | 'warn' }): JSX.Element;
