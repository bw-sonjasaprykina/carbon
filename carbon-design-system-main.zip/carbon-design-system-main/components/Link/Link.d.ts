import * as React from 'react';

/** Carbon Link — standalone or inline, three sizes, with optional trailing icon. */
export interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  children: React.ReactNode;
  href?: string;
  /** 12 / 14 / 16px. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Inline links are always underlined; standalone links underline on hover. @default false */
  inline?: boolean;
  disabled?: boolean;
  /** Renders the visited colour. @default false */
  visited?: boolean;
  /** Trailing icon, e.g. <Icon name="Launch" size={16} />. */
  renderIcon?: React.ReactNode;
}
export declare function Link(props: LinkProps): JSX.Element;
