Text navigation. \`inline\` for links inside a paragraph (always underlined); standalone for links on their own line (underline on hover only).

\`\`\`jsx
<Link href="/docs" renderIcon={<Icon name="Launch" size={16} />}>Read the docs</Link>
<p className="cds-body-01">See the <Link inline href="#">migration guide</Link> for details.</p>
\`\`\`

Sizes are sm 12px / md 14px / lg 16px. Standalone links with an icon use a 4px gap.
